<?php
include 'koneksi.php';

$isbn = ($_GET['isbn']);

// Query untuk menghapus data
$sql = mysqli_query($koneksi, "DELETE FROM buku WHERE isbn='$isbn'");
header("location:buku.php");
?>