<?php 
include 'koneksi.php';
include("header.php"); 
?>

<div class="album py-5 fade-in-up"><br><br> <!--bg-body-tertiary-->
    <h2 align="center"><strong>Daftar Penulis</strong></h2><br>
        <div class="container shadow-sm px-4 py-2 bg-body-tertiary rounded text-dark bg-opacity-50">
            <div align="left" class="row row-cols-sm-6 g-3 d-grid gap-2 d-md-block m-1">
                    
                <button type="button" class="btn btn-success">
                    <a href="tambahpenulis.php" class="white-link">
                        <i class="bi bi-plus-circle-dotted"></i>
                        Tambah Penulis
                    </a>
                </button>

                <table class="table table-bordered">
                    <thead>
                    <tr class="table-info text-center">
                        <th scope="col">ID Penulis</th>
                        <th scope="col">Nama Penulis</th>
                        <th class="col" width="200">Action</th>
                    </tr>
                    </thead>
                    <tbody class="text-center">
                    <?php
                            $penulis = mysqli_query($koneksi, "select * from penulis");
                            $nomor = 1;
                            while($row = mysqli_fetch_array($penulis)){ 
                            ?>
                            <tr>
                                <th><?php echo $nomor;?></th>
                                <td><?php echo $row['nama_penulis']?></td>
                                <td align="center">
                                    <div class="">
                                        <a href="editpenulis.php?id_penulis=<?php echo $row['id_penulis']?>" class="btn btn-primary" style=" --tooltip-width: 80px" data-tooltip="Edit">
                                            <i class="bi bi-pencil-square"></i>
                                        </a>
                                        <a href="hapuspenulis.php?id_penulis=<?php echo $row['id_penulis']?>" class="btn btn-danger" style="--tooltip-width: 80px" data-tooltip="Hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                                            <i class="bi bi-trash3-fill"></i>
                                        </a>
                            </tr>
                        <?php
                        $nomor++;
                        }
                        ?>
                     

                
                    </tbody>
                </table>
            </div>
        </div>
</div>

</body>


<!--include 'footer.php';

                    while($buku = mysqli_fetch_array($query)){
                    echo "<tr>";

                        echo "<td>".$buku['isbn']."</td>";
                        echo "<td>".$buku['judul']."</td>";
                        echo "<td>".$buku['id_kategori']."</td>";
                        echo "<td>".$buku['id_penulis']."</td>";
                        echo "<td>".$buku['deskripsi']."</td>";
                        echo "<td>".$buku['harga']."</td>";

                        echo "<td>";
                        echo "<button><a href='form-edit.php?id=".$buku['isbn']."'>Edit</a></button> ";
                        echo "<button><a href='hapus.php?id=".$buku['isbn']."'>Hapus</a></button>";
                        echo "</td>";

                    echo "</tr>";
                    
                        
-->