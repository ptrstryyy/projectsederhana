function readMore(event) {
    let full = event.target.getAttribute("full-string-data");
    let show_less = '<a class="link-offset-2 link-offset-2-hover link-underline link-underline-opacity-0 link-underline-opacity-75-hover show-less">show less</a>';
    let parent = event.target.parentNode;
    
    parent.innerHTML = full + show_less;
    parent.lastChild.addEventListener("click", showLess);
}

function showLess(event) {
    let full = event.target.parentNode.firstChild.wholeText;
    let read_more = '&hellip;<a class="link-offset-2 link-offset-2-hover link-underline link-underline-opacity-0 link-underline-opacity-75-hover read-more" full-string-data="' + full  + '">read more</a>'
    let parent = event.target.parentNode;
    
    parent.innerHTML = full.slice(0, 150) + read_more;
    parent.lastChild.addEventListener("click", readMore);
}

document.addEventListener("DOMContentLoaded", () => {
    let read_more_button = document.querySelectorAll(".read-more");
    read_more_button.forEach(function (element) {
        element.addEventListener("click", readMore)
    });
});
