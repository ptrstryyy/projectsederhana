<?php
    include 'koneksi.php';

    $isbn = $_POST['isbn'];
    $judul = $_POST['judul'];
    $kategori = $_POST['id_kategori'];
    $penulis = $_POST['id_penulis'];
    $deskripsi = $_POST['deskripsi'];
    $harga = $_POST['harga'];

    $target_dir="img/cover/";
    $cover=$_FILES["cover"]["name"];
    $target_file=$target_dir.basename($cover);
    $namasementara=$_FILES["cover"]['tmp_name'];
    $terupload=move_uploaded_file($namasementara, $target_file);
    
    $sql = mysqli_query($koneksi,"INSERT into buku (isbn, cover, judul, id_kategori, id_penulis, deskripsi, harga) values ('$isbn','$cover','$judul','$kategori','$penulis','$deskripsi','$harga')");
    
    header("location: buku.php");

?>


 