<?php 
include("header.php");
include('koneksi.php');
?>

<div class="album py-5 fade-in-up"><br><br> <!--bg-body-tertiary-->
        <h2 align="center" class="text-white"><strong>Tambah Data Buku</strong></h2><br>
            <div class="container shadow-sm p-3 mb-5 bg-body-tertiary rounded text-dark bg-opacity-50">
                <div align="left" class="">
                        
                    <table class="table table-bordered">
                        
                        <form action="simpanbuku.php" method="POST" enctype="multipart/form-data">
                            <div class="mb-3 row">
                                <label for="isbn" class="col-sm-2 col-form-label">ISBN</label>
                                <div class="col-sm-10">
                                  <input type="text" class="form-control" id="isbn" name="isbn" placeholder="masukan nomor ISBN" required>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="judul" class="col-sm-2 col-form-label">Judul Buku</label>
                                <div class="col-sm-10">
                                  <input type="text" class="form-control" id="judul" name="judul" placeholder="masukan judul buku" required>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label for="penulis" class="col-sm-2 col-form-label">Penulis </label>
                                <div class="col-sm-9">
                                    <select name="id_penulis" class="form-control">
                                        <?php
                                        $penulis=mysqli_query($koneksi,"SELECT * FROM penulis");
                                        while ($p=mysqli_fetch_array($penulis)) {
                                            echo "<option value=' ".$p['id_penulis']."'>".$p['nama_penulis']."</option> ";
                                        }

                                        ?>
                                    </select>
                                </div>
                                <div class="col-1">
                                    <a href="penulis.php" type="button" class="btn btn-outline-warning" style=" --tooltip-width: 100px" data-tooltip="Edit Penulis">
                                        <i class="bi bi-box-arrow-up-right"></i>
                                    </a>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label for="kategori" class="col-sm-2 col-form-label">Kategori </label>
                                <div class="col-sm-9">
                                    <select name="id_kategori" class="form-control">
                                        <?php
                                        $kategori=mysqli_query($koneksi,"SELECT * FROM kategori");
                                        while ($k=mysqli_fetch_array($kategori)) {
                                            echo "<option value=' ".$k['id_kategori']."'>".$k['nama_kategori']."</option> ";
                                        }
                                        
                                        ?>
                                    </select>
                                </div>
                                <div class="col-1">
                                    <a href="kategori.php" type="button" class="btn btn-outline-warning" style=" --tooltip-width: 110px" data-tooltip="Edit Kategori">
                                        <i class="bi bi-box-arrow-up-right"></i>
                                    </a>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label for="deskripsi" class="col-sm-2 col-form-label">Deskripsi </label>
                                <div class="col-sm-10">
                                    <textarea class="form-control" id="exampleFormControlTextarea1" name="deskripsi" rows="3" placeholder="masukan deskripsi"></textarea>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label for="harga" class="col-sm-2 col-form-label">Harga </label>
                                <div class="col-sm-10">
                                  <input type="text" class="form-control" id="harga" name="harga" placeholder="masukan harga" required>
                                </div>
                            </div>
                            <div class="mb-3 row">  
                                <label for="file" class="col-sm-2 col-form-label">Cover </label><br>
                                <div class="col-sm-10"><!--button search file-->
                                    <input type="file" id="cover" name="cover" class="form-control" accept="image/*" />
                                </div>
                            </div>
                            <br> 
                            
                            <!-- Submit button -->
                            <div>
                                <button type="submit" class="btn btn-success me-md-2">Tambah</button>
                                <button type="button" class="btn btn-danger"><a href="buku.php" class="white-link"> Batal </a></button>
                            </div>
                            </form>
                    </table>
                </div>

                
            </div>
        </div>

</body>


<!--include 'footer.php';

                    while($buku = mysqli_fetch_array($query)){
                    echo "<tr>";

                        echo "<td>".$buku['isbn']."</td>";
                        echo "<td>".$buku['judul']."</td>";
                        echo "<td>".$buku['id_kategori']."</td>";
                        echo "<td>".$buku['id_penulis']."</td>";
                        echo "<td>".$buku['deskripsi']."</td>";
                        echo "<td>".$buku['harga']."</td>";

                        echo "<td>";
                        echo "<button><a href='form-edit.php?id=".$buku['isbn']."'>Edit</a></button> ";
                        echo "<button><a href='hapus.php?id=".$buku['isbn']."'>Hapus</a></button>";
                        echo "</td>";

                    echo "</tr>";
                    


                    
                        
-->