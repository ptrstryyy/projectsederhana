<?php
session_start();
if (isset($_SESSION['nama'])) {
    header("location:buku.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!--required meta tags-->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- JavaScript -->
    <script id="js/bootstrap.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdn.datatables.net/2.1.8/js/dataTables.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <!-- Custom CSS files -->
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/coji-style.css">

    <!--judul jangan lupa ganti -ptr-->
    <link rel="shortcut icon" href="img/logo.png">
    <title>Project 1 - Data Buku Putri</title>
</head>
</html>

<body>
    <div class="div1">
		<div class="div1-isi">
            <div class="fade-in-left">
                <form action="login.php" method="POST"> <!--untuk POST itu tidak menampilkan url,kalau GET dapat menampilkan apa yg kita input diform akan muncul di url (untuk file password lebih baik menggunakan POST)-->
                    <h3>LOG IN</h3>
                    <div class="form-floating">
                        <input type="text" name="username" class="form-control" id="floatingInput" placeholder="Masukan Username">
                        <label for="floatingInput">username atau email</label>
                    </div>
                    <div class="form-floating">
                        <input type="password" name="password" class="form-control" id="floatinginput" placeholder="Masukan Password">
                        <label for="floatingpassword">password</label>
                    </div>
                    <button type="submit" class="btn btn-info"><a style="color: white;">Login</a></button>
                </form>
            </div>
            <div class="container">
			    <img src="img/index2.png" alt="namaAnimasi" class="img1 fade-in-right" >
            </div>
		</div>
        <div class="footer fade-in-bottom">
            <p>Copyright © 2024 | @ptrstryyy</p>
        </div>
	</div>


<!--include 'footer.php';-->
