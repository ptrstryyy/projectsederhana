<?php include("header.php"); ?>

<div class="album py-5 fade-in-up"><br><br> <!--bg-body-tertiary-->
        <h2 align="center" class="text-white"><strong>Tambah Kategori Buku</strong></b></h2><br>
            <div class="container shadow-sm p-3 mb-5 bg-body-tertiary rounded text-dark bg-opacity-50">
                <div align="left" class="">
                        
                    <table class="table table-bordered">
                        
                        <form action="simpankategori.php" method="POST">
                            <!--<div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">ID Kategori</label>
                                <div class="col-sm-10">
                                  <input type="password" class="form-control" id="inputPassword" placeholder="Masukan ID Kategori">
                                </div>
                            </div>-->

                            <div class="mb-3 row">
                                <label for="inputtext" class="col-sm-2 col-form-label">Nama Kategori </label>
                                <div class="col-sm-10">
                                  <input type="text" class="form-control" id="inputtext" name="nama_kategori" placeholder="masukan nama kategori" required>
                                </div>
                            </div>
                            <br>
                            <!-- Submit button -->
                            <div>
                                <button type="submit" class="btn btn-success me-md-2">Tambah</button>
                                <button type="button" class="btn btn-danger"><a href="kategori.php" class="white-link"> Batal </a></button>
                            </div>
                            </form>
                    </table>
                </div>

                
            </div>
        </div>

</body>


<!--include 'footer.php';

                    while($buku = mysqli_fetch_array($query)){
                    echo "<tr>";

                        echo "<td>".$buku['isbn']."</td>";
                        echo "<td>".$buku['judul']."</td>";
                        echo "<td>".$buku['id_kategori']."</td>";
                        echo "<td>".$buku['id_penulis']."</td>";
                        echo "<td>".$buku['deskripsi']."</td>";
                        echo "<td>".$buku['harga']."</td>";

                        echo "<td>";
                        echo "<button><a href='form-edit.php?id=".$buku['isbn']."'>Edit</a></button> ";
                        echo "<button><a href='hapus.php?id=".$buku['isbn']."'>Hapus</a></button>";
                        echo "</td>";

                    echo "</tr>";
                    
                        
-->