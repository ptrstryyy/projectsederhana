<?php 
include 'koneksi.php';
include("header.php"); 
?>

<style>
    $box-shadow-sm: 0 .125rem .25rem rgba($black, .075);
</style>

<section class="container">
<div class="album py-5">
    <h2 align="center" class=""><strong>Daftar Buku</strong></h2><br>
    <div class="container shadow-sm p-4 mb-5 bg-body-tertiary rounded text-dark bg-opacity-50"> <!--bg-body-tertiary-->
        <div class="container">
            <div align="left" class="table-responsive">
                <button type="button" class="btn btn-success">
                    <a href="tambahbuku.php" class="white-link">
                        <i class="bi bi-plus-circle-dotted"></i>
                        Tambah data baru
                    </a>
                </button>
                <table id="example" class="table table-striped table-hover">
                    <thead>
                        <tr class="table-striped table-hover text-center">
                            <th scope="col">No</th>
                            <th scope="col">ISBN</th>
                            <th scope="col">Cover</th>
                            <th scope="col">Judul</th>
                            <th scope="col">Kategori</th>
                            <th scope="col">Penulis</th>
                            <th scope="col">Deskripsi</th>
                            <th scope="col">Harga</th>
                            <th class="col" width="200">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $buku = mysqli_query($koneksi, "SELECT buku.isbn, buku.cover, buku.judul, buku.deskripsi, buku.harga, kategori.nama_kategori, penulis.nama_penulis 
                        FROM buku JOIN kategori ON kategori.id_kategori=buku.id_kategori JOIN penulis ON penulis.id_penulis=buku.id_penulis");
        
                        $nomor = 1;
                        while($row = mysqli_fetch_array($buku)){ 
                        ?>
                        <tr class="text-center">
                            <th><?php echo $nomor;?></th>
                            <td><?php echo $row['isbn']?></td>
                            <td><img src="img/cover/<?php echo $row['cover']?>" width="200"></td>
                            <td><?php echo $row['judul']?></td>
                            <td><?php echo $row['nama_kategori']?></td>
                            <td><?php echo $row['nama_penulis']?></td>
                            <td>
                                <?php
                                echo substr($row['deskripsi'], 0, 150) 
                                    . (strlen($row['deskripsi']) > 150 ? '...<a class="link-offset-2 link-offset-2-hover link-underline link-underline-opacity-0 link-underline-opacity-75-hover read-more" full-string-data="'. $row['deskripsi'] .'">read more</a>' : '');
                                ?>
                                
                            </td>
                            <td><?php echo "Rp" . number_format($row['harga'], 2, ",", ".")?></td>
                            <td align="center">
                                <!-- <div class=""> -->
                                    <a href="editbuku.php?isbn=<?php echo $row['isbn']?>" class="btn btn-primary" style="--tooltip-width: 80px" data-tooltip="Edit">
                                        <i class="bi bi-pencil-square"></i>
                                    </a>
                                    <a href="hapusbuku.php?isbn=<?php echo $row['isbn']?>" class="btn btn-danger" style="--tooltip-width: 80px" data-tooltip="Hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                                        <i class="bi bi-trash3-fill"></i>
                                    </a>
                                <!-- </div> -->
                        </tr>
                        <?php
                        $nomor++;
                        }
                        ?>
                    <tbody>
                    </tbody>
                </table>


            </div>
        </div>
    </div>
  </div>
</section>







  

<script>
    $(document).ready(function(){
        $("#example").DataTable({
        });
    } );
</script>

<?php include("footer.php"); ?>


<!--<div class="row py-3" style="height: 100vh;">
        <div class="col-5">
            <img src="img/index1-min.png" alt="index1" class="img1" width="480px">
        </div>
        <div class="col-7 pt-3">
            <div class="row" style="padding: 150px 50px 300px 20px;">
                    <h1 class="fw-light">Album example</h1>
                    <p class="lead text-body-secondary">Something short and leading about the collection below—its contents, the creator, etc. Make it short and sweet, but not too short so folks don’t simply skip over it entirely.</p>
                    <p>
                    <a href="#" class="btn btn-primary my-2">Main call to action</a>
                    <a href="#" class="btn btn-secondary my-2">Secondary action</a>
                    </p>
            </div>
        </div>
    </div>-->






<!--include 'footer.php';

                    while($buku = mysqli_fetch_array($query)){
                    echo "<tr>";

                        echo "<td>".$buku['isbn']."</td>";
                        echo "<td>".$buku['judul']."</td>";
                        echo "<td>".$buku['id_kategori']."</td>";
                        echo "<td>".$buku['id_penulis']."</td>";
                        echo "<td>".$buku['deskripsi']."</td>";
                        echo "<td>".$buku['harga']."</td>";

                        echo "<td>";
                        echo "<button><a href='form-edit.php?id=".$buku['isbn']."'>Edit</a></button> ";
                        echo "<button><a href='hapus.php?id=".$buku['isbn']."'>Hapus</a></button>";
                        echo "</td>";

                    echo "</tr>";
                    

                    
session_start();
include 'koneksi.php';  /*include 'header.php'; //get_header();*/

$sql = "SELECT * FROM buku";
$query = mysqli_query($db, $sql);
$buku = mysqli_fetch_array($query)

                        
-->