<?php 
include("header.php");
include 'koneksi.php';
$id = $_GET['isbn'];
$sql = mysqli_query($koneksi,"SELECT * FROM buku WHERE isbn = '$id'");
$isbn = mysqli_fetch_array($sql);
?>

<style>
    $box-shadow-sm: 0 .125rem .25rem rgba($black, .075);
</style>

<div class="album py-5 fade-in-up"> <!--bg-body-tertiary-->
        <h2 align="center" class="text-white"><strong>Edit Data Buku</strong></h2><br>
            <div class="container shadow-sm p-3 mb-5 bg-body-tertiary rounded p-2 text-dark bg-opacity-50">
                <div align="left" class="">
                        
                    <table class="table table-bordered">
                        
                        <form action="updatebuku.php" method="POST" enctype='multipart/form-data'>
                            <div class="mb-3 row">
                                <label for="isbn" class="col-sm-2 col-form-label">ISBN</label>
                                <div class="col-sm-10">
                                  <input value="<?php echo $isbn['isbn'];?>" type="text" class="form-control" id="isbn" name="isbn" placeholder="masukan nomor ISBN">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label for="judul" class="col-sm-2 col-form-label">Judul Buku</label>
                                <div class="col-sm-10">
                                  <input value="<?php echo $isbn['judul'];?>" type="text" class="form-control" id="judul" name="judul" placeholder="masukan judul buku">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label for="penulis" class="col-sm-2 col-form-label">Penulis </label>
                                <div class="col-sm-9">
                                    <select name="id_penulis" class="form-select">
                                        <?php
                                        $penulis=mysqli_query($koneksi,"SELECT * FROM penulis");
                                        while ($p=mysqli_fetch_array($penulis)) {
                                            echo "<option value=' ".$p['id_penulis']."' ";  
                                            echo $p['id_penulis']==$isbn['id_penulis']? ' selected':'';
                                            echo ">".$p['nama_penulis']."</option> ";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-1">
                                    <a href="penulis.php" type="button" class="btn btn-outline-warning" style=" --tooltip-width: 100px" data-tooltip="Edit Penulis">
                                        <i class="bi bi-box-arrow-up-right"></i>
                                    </a>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label for="kategori" class="col-sm-2 col-form-label">Kategori </label>
                                <div class="col-sm-9">
                                    <select name="id_kategori" class="form-select">
                                        <?php
                                        $kategori=mysqli_query($koneksi,"SELECT * FROM kategori");
                                        while ($k=mysqli_fetch_array($kategori)) {
                                            echo "<option value=' ".$k['id_kategori']."' ";  
                                            echo $k['id_kategori']==$isbn['id_kategori']? ' selected':'';
                                            echo ">".$k['nama_kategori']."</option> ";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-1">
                                    <a href="kategori.php" type="button" class="btn btn-outline-warning" style=" --tooltip-width: 110px" data-tooltip="Edit Kategori">
                                        <i class="bi bi-box-arrow-up-right"></i>
                                    </a>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label for="deskripsi" class="col-sm-2 col-form-label">Deskripsi </label>
                                <div class="col-sm-10">
                                    <textarea name="deskripsi" class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="masukan deskripsi buku"><?php echo $isbn['deskripsi'];?>"</textarea>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label for="harga" class="col-sm-2 col-form-label">Harga </label>
                                <div class="col-sm-10">
                                    <input value="<?php echo $isbn['harga'];?>" type="text" class="form-control" id="harga" name="harga" placeholder="masukan harga"></textarea>
                                </div>
                            </div>
                            <div class="mb-3 row">  
                                <label for="file" class="col-sm-2 col-form-label">Cover </label><br>
                                <div class="col-sm-10"><!--button search file-->
                                    <input value="<?php echo $isbn['cover'];?>" type="file" id="cover" name="cover" class="form-control" accept="image/*" />
                                </div>
                            </div>
                            <br>    

                            
                          
                            <!-- Submit button -->
                            <div>
                                <button type="submit" class="btn btn-success me-md-2">Simpan</button>
                                <button type="submit" class="btn btn-danger"><a href="buku.php" class="white-link"> Batal </a></button>
                            </div>
                            </form>
                    </table>
                </div>

            </div>
        </div>

</body>


<!--include 'footer.php';

                    while($buku = mysqli_fetch_array($query)){
                    echo "<tr>";

                        echo "<td>".$buku['isbn']."</td>";
                        echo "<td>".$buku['judul']."</td>";
                        echo "<td>".$buku['id_kategori']."</td>";
                        echo "<td>".$buku['id_penulis']."</td>";
                        echo "<td>".$buku['deskripsi']."</td>";
                        echo "<td>".$buku['harga']."</td>";

                        echo "<td>";
                        echo "<button><a href='form-edit.php?id=".$buku['isbn']."'>Edit</a></button> ";
                        echo "<button><a href='hapus.php?id=".$buku['isbn']."'>Hapus</a></button>";
                        echo "</td>";

                    echo "</tr>";
                    
                        
-->