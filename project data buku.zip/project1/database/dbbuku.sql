-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 05, 2024 at 08:14 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbbuku`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `isbn` varchar(8) NOT NULL,
  `cover` text NOT NULL,
  `judul` varchar(255) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `id_penulis` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`isbn`, `cover`, `judul`, `id_kategori`, `id_penulis`, `harga`, `deskripsi`) VALUES
('10010', 'twilight.jpg', 'Twilight', 1, 1, 110000, 'Bella mulai mengenal Edward Cullen pada hari pertama sekolahnya, tetapi tidak ada sambutan hangat yang diberikan oleh Edward kepada Bella. Bella yang tidak mengerti mengenai Edward Cullen serta kemampuan-kemampuan mistisnya bertanya kepada sahabatnya Jacob Black. Bellapun mengetahui bahwa sesungguhnya Edward adalah seorang vampir vegetarian, mereka tidak memangsa manusia namun memangsa hewan. Edward dan Bella mulai saling terbuka dan akhirnya mereka jatuh cinta.\"\"\"'),
('10020', 'newmoon.jpg', 'New Moon', 1, 1, 110000, 'New Moon adalah novel karangan Stephenie Meyer yang merupakan bagian dari Seri novel Twilight. Novel ini merupakan seri kedua dan merupakan novel lanjutan dari Twilight yang menceritakan tentang kisah asmara antara Bella Swan dan Edward Cullen. Novel ini akan dirilis kedalam layar lebar pada bulan November 2009. Di dalam Novel ini pula dikisahkan hubungan Bella Swan dengan Jacob Black, seorang Werewolf (Manusia Serigala). Dalam Novel ini pula diceritakan tentang Keluarga Volturi yang berdiam di kota Volterra, Italy. \"'),
('10030', 'eclipse.jpg', 'Eclipse', 1, 1, 110000, 'Victoria, vampir yang dendam terhadap Bella pun berkeliaran di Forks untuk mencari celah membunuh Bella. Dia pun membuat suatu pasukan \"vampir baru\" untuk membantunya melawan Keluarga Cullen dan membunuh Bella. Sementara itu, Bella harus memilih antara hubungannya dengan Edward atau persahabatannya dengan Jacob(karna ternyata Jacob jatuh cinta juga pada Bella). Keluarga Cullen dan Geng werewolf Jacob terpaksa bekerja sama untuk memusnakan vampir–vampir baru buatan Victoria. Sehingga mereka sukses membasmi Victoria beserta pasukkannya. Jacob pun marah mengetahui pilihan Bella yang memutuskan menjadi vampir. Dia berusaha menyakinkan Bella bahwa Bella itu juga mencintainya meskipun tidak sebesar cintanya kepada Edward. Namun Bella menyadarkannya bahwa bella tidak akan sanggup hidup tanpa Edward disisinya. Akhirnya dengan berat hati ia merelakan hubungan Edward dengan Bella dan untuk beberapa saat dia pergi jauh dari hidupnya Bella. \"'),
('10040', 'breakingdawn.jpg', 'Breaking Dawn', 1, 1, 110000, 'Bella dan Edward menikah, tetapi bulan madu mereka terpotong setelah Bella mengetahui bahwa dirinya hamil. Kehamilannya berjalan amat cepat dan membuat Bella menjadi lemah. Ia hampir meninggal saat melahirkan putrinya yang setengah manusia dan setengah vampir, Renesmee(diambil dari nama Renee dan Esme), tetapi Edward menyuntikkan racunnya langsung ke jantung Bella sehingga berubah menjadi seorang vampir. Irina, vampir dari clan Denali tanpa sengaja melihat Renesmee dan Jacob saat dia berada di Forks. Lalu ia pun menyangka Renesmee sebagai \"immortal child\"—anak yang diciptakan oleh vampir.( Dalam dunia vampir, penciptaan anak-anak vampir sangat dilarang demi menjaga kerahasiaan mereka ). Kemudian Irina melaporkan hal tersebut langsung kepada Klan Volturi. Merasa was-was, Keluarga Cullen pun mengumpulkan vampir-vampir yang dapat menjadi saksi bahwa Reneesme bukan \"immortal child\". Berkat daya tarik Renesmee yang membuat semua vampir terpikat dan didukung dengan kemampuannya memperlihatkan semua yang ia alami ...\"'),
('10050', '', 'The Hunger Games', 1, 2, 142000, 'The Hunger Games adalah novel fiksi ilmiah tahun 2008 karangan penulis Amerika Serikat Suzanne Collins. Novel ini dikisahkan dalam sudut pandang seorang gadis umur 16 tahun bernama Katniss Everdeen, yang tinggal di sebuah negara distopia pascaapokalips bernama Panem di Amerika Utara. Capitol, ibu kota metropolis yang sangat maju, memegang kendali politik atas keseluruhan negara. The Hunger Games adalah acara tahunan yang diikuti oleh seorang anak laki-laki dan perempuan yang berusia antara 12–18 tahun dari dua belas distrik di sekeliling Capitol, yang dipilih melalui pengundian untuk bersaing dalam pertarungan mematikan yang disiarkan secara langsung di televisi.  '),
('10060', '', 'Catching Fire ', 1, 2, 142000, 'Kemenangan Katniss Everdeen dan Peeta Mellark dalam Hunger Games berbuntut panjang. Kemenangan mereka menyulut api pemberontakan para penduduk di beberapa distrik. Oleh sebab itu, Presiden Snow berkunjung ke rumah Katniss. Membahas tentang tur kemenangannya. Atau lebih tepatnya, memintanya melakukan apa yang disuruhkan saat tur kemenangannya untuk meredam percikan pemberontakan pada para penduduk. Caranya mudah, dia hanya harus meyakinkan para penduduk di semua distrik bahwa Katniss benar-benar jatuh cinta pada Peeta, seperti halnya Peeta yang sepenuh hati mencintai Katniss. Masalahnya, Peeta sedikit marah pada Katniss tepat saat mereka kembali ke Distrik 12 setelah mereka memenangkan Hunger Games dan mereka saling menjauh. Dilain pihak, Katniss bingung dengan perasaannya terhadap sahabatnya, Gale Hawthorne karena tampaknya Gale mulai menunjukkan ketertarikannya pada Katniss. '),
('10070', '', 'Mockingjay ', 1, 2, 142000, 'Katniss Everdeen selamat dari Hunger Games, dua kali. Setelah diloloskan dari Quarter Quell oleh kelompok pemberontak dari Distrik 13 yang sebelum ini diyakininya sudah musnah, Katniss menjalani sesi-sesi latihan dalam kota bawah tanah di Distrik 13 untuk menjadikannya seorang pejuang, pemberontak. Seorang Mockingjay.\r\n\r\nSementara itu, Capitol makin membenci Katniss. Capitol menghujani Distrik 12 dengan bom. Sementara itu, Peeta Mellark jadi tawanan Capitol. Katniss berasumsi Peeta sudah tewas. Sayangnya Peeta masih hidup. Peeta ditampilkan di TV dan disiarkan ke seantero Panem dan dia dianggap sebagai pengkhianat. Kemudian para pemberontak berhasil menculiknya dan membawanya ke Distrik 13. Celakanya, Peeta sudah berubah 180 derajat. Ia ditahan dan disiksa sedemikian rupa oleh Capitol. Peeta telah dibajak dan dicuci otak. Segala kenangan masa lalunya, terutama yang berhubungan dengan Katniss, diobrak-abrik dengan racun tawon penjejak. Peeta yang baru ini melihat Katniss sebagai mutt (makhluk buas ciptaan Capito'),
('10080', '', 'Anna Karenina', 1, 3, 95000, 'Anna Karenina adalah sebuah karya monumental dari sastrawan Rusia, Leo Tolstoy. Diterbitkan secara keseluruhan pada tahun 1878, novel ini mengeksplorasi topik-topik seperti pernikahan, perjudian, dan feodalisme di Rusia. Majalah Time bahkan menobatkannya sebagai novel terbaik sepanjang masa.\r\n\r\nNovel ini mengisahkan dua karakter utama: Anna, seorang ibu rumah tangga yang kabur dengan kekasihnya yang lebih muda, dan Konstantin Levin, seorang pemilik tanah yang mengalami cinta dan kebingungan hidup.\r\n\r\nTolstoy dengan brilian menggabungkan tema cinta, rasa sakit, dan keluarga dalam konteks masyarakat Rusia. Karya ini dianggap revolusioner karena cara perlakuan terhadap wanita dan penggambaran kesulitan mereka pada saat itu.'),
('10090', '', 'To Kill a Mockingbird', 1, 4, 46000, 'Ditulis oleh Harper Lee, To Kill a Mockingbird diterbitkan pada tahun 1960 dan segera menjadi karya sastra klasik. Novel ini mengkaji rasisme di Amerika Selatan melalui sudut pandang seorang gadis bernama Jean Louise (Scout) Finch. Pada tahun 1961, To Kill a Mockingbird memenangkan Hadiah Pulitzer untuk fiksi dan diadaptasi menjadi film pemenang Academy Award pada tahun 1962.\r\n\r\nKarya Harper Lee ini dianggap sangat berpengaruh karena penggambaran mendalam mengenai ketidakadilan rasial dan moralitas manusia. Karakter-karakternya yang kuat dan alur cerita yang menyentuh hati membuat novel ini menjadi salah satu yang terbaik sepanjang masa.'),
('10110', '', 'The Great Gatsby', 1, 5, 68000, 'The Great Gatsby karya F. Scott Fitzgerald mengisahkan cerita melalui sudut pandang Nick Carraway, seorang pemuda yang baru pindah ke New York dan berteman dengan Jay Gatsby, seorang pria kaya dengan asal usul misterius. Novel ini memberikan pandangan mendalam tentang era Jazz tahun 1920-an di Amerika Serikat dan secara bersamaan mengkritik gagasan American Dream.\r\n\r\nAmerican Dream adalah konsep bahwa Amerika adalah tanah yang menjanjikan banyak peluang, di mana siapa saja yang bekerja keras dapat mencapai kehidupan dan status sosial yang lebih baik. Namun, Fitzgerald dengan cermat menyoroti bagaimana kapitalisme dan konsumsi tinggi dapat merusak nilai-nilai tersebut.'),
('10120', '', 'One Hundred Years of Solitude', 1, 6, 60000, 'One Hundred Years of Solitude diterbitkan pada tahun 1967. Novel ini mengisahkan tujuh generasi keluarga Buendia, pendirian kota fiksi Macondo, serta kehancurannya bersama dengan keturunan terakhir mereka. Marquez menerima Hadiah Nobel untuk sastra pada tahun 1982, dengan One Hundred Years of Solitude dianggap sebagai karyanya yang paling berjaya.\r\n\r\nNovel ini sering dipuji karena kemampuannya menggambarkan sejarah Amerika Latin dan kerusakan sistem yang akhirnya menghancurkan kota. Gaya penulisan Marquez yang magis dan realistis membuat karya ini menjadi salah satu yang paling berpengaruh dalam dunia sastra.'),
('10130', '', 'Don Quixote', 1, 7, 199000, 'Don Quixote diterbitkan secara lengkap pada tahun 1615 dan dianggap sebagai salah satu karya sastra terbaik sepanjang masa. Novel ini menceritakan kisah seorang pria yang menjadi gila karena terlalu banyak membaca kisah romansa ksatria. Ia memutuskan untuk menjadi seorang ksatria pengembara dengan nama Don Quixote.\r\n\r\nKarakter Don Quixote telah mempengaruhi banyak karya seni, musik, dan sastra sejak novel ini diterbitkan. Kisahnya yang penuh petualangan, komedi, dan tragedi membuat novel ini tetap relevan hingga saat ini. Di akhir cerita, Don Quixote diceritakan jatuh sakit dan meninggal dunia, menyisakan pesan mendalam tentang mimpi dan kenyataan.'),
('20010', '', 'Dragon Ball ', 2, 8, 34000, 'Dragon Ball adalah salah satu komik dan anime legendaris karya Akira Toriyama. Komiknya pertama kali rilis pada 3 Desember tahun 1984 lalu. Tak lama kemudian, pada 26 Februari 1986, animenya menyusul. Di Indonesia sendiri, Dragon Ball sempat menjadi anime paling populer di medio 90-an.\r\n\r\nBercerita tentang petualangan Son Goku, Bulma, Krillin dan teman-temannya untuk mencari 7 bola naga yang dapat mengabulkan permintaan apapun. Mereka harus melalui berbagai halangan, mengalahkan banyak musuh, dan melewati latihan super berat untuk mengumpulkan ketujuh bola naga.'),
('20020', '', 'Inuyasha', 2, 9, 34000, 'Inuyasha merupakan komik dan anime yang menceritakan tentang Kagome, seorang remaja sekolah menengah atas yang terjatuh ke dalam sumur di kuil keluarganya sendiri. Setelah terjatuh, Kagome lalu menyadari bahwa dirinya berada di era Sengoku setelah bertemu dengan Inuyasha yang merupakan manusia setengah siluman.'),
('20030', '', 'Naruto', 2, 10, 34000, 'Sebuah serial manga karya Masashi Kishimoto yang diadaptasi menjadi serial anime. Manga Naruto bercerita seputar kehidupan tokoh utamanya, Naruto Uzumaki, seorang ninja yang hiperaktif, periang, dan ambisius yang ingin mewujudkan keinginannya untuk mendapatkan gelar Hokage, pemimpin dan ninja terkuat di desanya. Serial ini didasarkan pada komik one-shot oleh Kishimoto yang diterbitkan dalam edisi Akamaru Jump pada Agustus 1997.'),
('20040', '', 'Fullmetal Alchemist', 2, 11, 34000, 'Vico Edward Elric dan Alphonse Elric awalnya hidup bahagia dengan orang tua mereka. Tetapi karena pekerjaan ayahnya adalah alkemist (ahli kimia), ayahnya yang bernama Van Hohenheim sering bepergian keluar rumah, sehingga Ed dan Al hanya tinggal bersama ibunya, Trisha Elric. Karena terlalu lelah mengurus rumah sendirian, Trisha jatuh sakit dan akhirnya meninggal. Ed dan Al yang saat itu masih kecil, namun sudah mewarisi bakat ayahnya sebagai alkemist mencoba menghidupkan kembali sang ibu. Namun, usaha mereka gagal. Tubuh Al dan kaki kiri Ed diambil sebagai \"biaya masuk\" karena transmutasi manusia adalah hal tabu dalam alkimia. Ed yang panik akhirnya memindahkan roh Al ke dalam baju zirah dengan bayaran tangan kanannya.\r\n\r\nDi tengah keputusasaannya, Ed mendapat tawaran untuk menjadi seorang alchemist kenegaraan (State Alchemist). setelah mempertimbangkan keuntungan memperoleh berbagai hak istimewa sehingga ia bisa menyelidiki dan mencari cara untuk mengembalikan tubuh mereka, Ed menerima tawaran itu. Tangan dan kaki Ed pun diganti dengan automail. Setelah itu, Ed mengikuti tes ujian alchemist kenegaraan dan lulus sebagai alchemist kenegaraan termuda dalam sejarah dan mendapat julukan Fullmetal Alchemist. Bersama dengan Al, dimulailah petualangan Ed guna mencari cara untuk mengembalikan tubuh mereka. '),
('20050', '', 'Attack on Titan', 2, 12, 34000, 'Dalam suatu sejarah alternatif sekitar 1800 tahun yang lalu, seorang manusia bernama Ymir Fritz berubah menjadi raksasa mirip manusia yang dikenal sebagai Titan (巨人 Kyojin) setelah melakukan perjanjian dengan \"Iblis dari Seluruh Bumi\". Ymir kemudian mati 13 tahun kemudian sebagai \"efek samping dari kekuatan tersebut\". Kekuatan tersebut diwariskan kepada para putrinya sebelum dibagi kepada sembilan individu yang mendirikan Kekaisaran Eldia. Sang Titan Perintis tetap berada di bawah kendali keluarga Fritz dan mereka kemudian menaklukkan negara Marley dan berkuasa di sana selama 1700 tahun. Namun, seabad sebelum peristiwa dalam cerita utama terjadi, Raja Eldia bernama Karl Fritz kecewa dengan sejarah kelam keluarganya dan mengatur rencana keruntuhan Eldia. Marley kemudian membuat orang Eldia yang tersisa menjadi warga kelas dua sembari mengancam untuk mengasingkan mereka ke Paradis sebagai Titan Murni yang tidak memiliki akal. '),
('20060', '', 'Haikyuu!', 2, 13, 34000, 'Haikyuu! merupakan komik anime dengan tema sport yang menceritakan perjalanan Shoyo Hinata mewujudkan mimpi untuk menjadi pemain voli profesional bersama klub bola voli SMA Karasuno.\r\n\r\nDi klub tersebut, Hinata bertemu dengan rivalnya, Tobio Kageyama. Bersama-sama, mereka berusaha mengembalikan masa kejayaan klub bola voli SMA Karasuno.'),
('30010', '', 'Jalan Baru Moderasi Beragama', 3, 14, 129000, 'Lembaga Kajian dan Kemitraan Strategis (LKKS) merupakan unit kerja pendukung Pimpinan Pusat Muhammadiyah yang dibentuk pasca Muktamar Muhammadiyah ke-48 tahun 2022 di Surakarta. Lembaga ini bertugas melakukan pengkajian isu-isu strategis dan kerjasama dengan institusi pemerintah, non-pemerintah, dan dunia usaha dalam rangka menghadirkan kemaslahatan Islam Berkemajuan di ranah keummatan, kebangsaan, dan kemanusiaan.'),
('30020', '', 'Jaksa Agung Soeprapto: Dan Sejarah Pertumbuhan Kejaksanaan Republik Indonesia', 3, 15, 129000, 'Kesadaran yang kuat pada sejarah akan menjadi pemandu yang lurus bagi sebuah lembaga dalam menentukan langkah-langkahnya. Citra baik sejarah Kejaksaan di masa lampau juga beranjak dari perjuangan Jaksa Agung Soeprapto demi institusi. Keberanian Jaksa Agung Soeprapto dikenal keras dan gigih dalam mengusut kejahatan serta tidak pandang bulu dalam menegakkan hukum. Selain itu, sejarah Kejaksaan sebagai officer van justitie di era Jaksa Agung Soeprapto juga berpengaruh dalam menjaga keamanan di wilayah Negara Kesatuan Republik Indonesia. Semangat perjuangan Jaksa Agung Soeprapto perlu diteladani oleh seluruh insan Adhyaksa di Tanah Air sebagaimana telah diejawantahkan secara runtut dalam buku ini. Dengan mengingat sejarah, saya berharap Kejaksaan dapat menjadi lembaga yang lebih dipercaya oleh masyarakat, bangsa, dan negara.'),
('30030', '', 'Berdaulat untuk Kesejahteraan Rakyat', 3, 16, 220000, 'Berdaulat untuk Kesejahteraan Rakyat: Festschrift Dasa Windu Sri Sultan Hamengku Buwono X mengukir perayaan dan prestasi sosok yang menjadi tonggak inspirasi bagi masyarakat luas. Memuat kumpulan esai, makalah, berikut cerita-cerita pribadi tokoh-tokoh nasional dari berbagai latar belakang akademis, budaya, dan sosial sebagai dedikasi pada Sri Sultan Hamengku Buwono X, buku ini menjadi cermin kebijaksanaan seorang pemimpin, tokoh budaya, serta pelindung seni yang membentuk sejarah Yogyakarta dan Indonesia.\r\n\r\nSebagai penghormatan kepada seorang tokoh yang telah memberikan dampak positif pada banyak generasi dan menginspirasi semua yang berusaha menjaga nilai-nilai kearifan lokal serta kemanusiaan, Berdaulat untuk Kesejahteraan Rakyat: Festschrift Dasa Windu Sri Sultan Hamengku Buwono X merupakan suatu persembahan kepada seorang pemimpin besar, budayawan, dan pengayom yang takkan terlupakan.\r\n'),
('30040', '', 'Penjaga Nyala Api Buddhayana', 3, 17, 95000, 'Hanya selang sekitar 1,5 tahun setelah Peristiwa G30S/1965, tepatnya 20 Mei 1967, Romo Maha Upasaka Pandita Phoa Krishnaputra menginisiasi Perayaan Waisak yang melibatkan umat Buddhis lintas sekte di Kota Medan. Padahal saat itu, situasi anti-Tionghoa masih sangat terasa. Orang Tionghoa dianggap “terlibat” dalam peristiwa Gestapu. Mereka juga distigma ateis, tak bertuhan atau tak beragama. Pada 10 Desember 1965, Kota Medan juga baru diguncang peristiwa kekerasan anti-Tionghoa. Ratusan orang Tionghoa mengalami tindak kekerasan penganiayaan, tokotoko mereka dijarah, beberapa gedung sekolah dan kantor organisasi disita.\r\n\r\nTahun 1968, Romo Phoa kembali menyelenggarakan Perayaan Waisak lintas sekte, yang dihadiri Pangdam II/Bukit Barisan, Brigjen TNI Sarwo Edhie Wibowo, pemimpin gerakan penumpasan PKI dan ormas yang dianggap menjadi onderbouw-nya di Sumatra Utara. Melihat konteks kala itu, penyelenggaraan Perayaan Waisak yang umumnya diikuti orang Tionghoa justru melindungi komunitas ini yang tengah menjadi sasaran sentimen antiTionghoa.'),
('40010', '', 'Kita Adalah Sekumpulan Patah Hati yang Memilih Matahari', 4, 18, 89000, 'Setiap manusia sebenarnya dilahirkan sebagai seorang murid yang selalu siap untuk mendapatkan pelajaran baru setiap harinya. Atas alasan inilah Astri Apriyani memutuskan untuk membuat sebuah buku antologi puisi yang ternyata didasarkan pada berbagai pengalamannya saat pergi menjelajahi dunia. Astri juga meyakini bahwa setiap perjalanan yang ia lalui juga merupakan bagian dari proses pembelajaran, sehingga ia ingin mengabadikan setiap kenangannya ke dalam beberapa tulisannya. Tidak hanya itu, Astri juga melengkapi isi buku ini dengan berbagai macam foto yang ia ambil sendiri, karena baginya, setiap tempat yang ia kunjungi punya artinya tersendiri.'),
('40020', '', 'Suaramu Jalan Pulang yang Kukenali', 4, 19, 65000, 'Jika kita lahir dan tumbuh sebagai kata-kata,\r\nsaya ingin bertemu kamu di kalimat yang\r\ntak pernah memuat tanda seru dan berpisah\r\ndi jalan yang ujungnya tak memuat tanda titik.\r\nSaya ingin bercinta dengan kamu kapan saja\r\ndi mana saja tanpa dipisahkan koma dan jeda.\r\n'),
('40030', '', 'Keterampilan Membaca Laut', 4, 20, 35000, 'Laut menyimpan separuh tubuhnya di kedua matamu.\r\nAku mengambil sebagian untuk tiga judul puisi\r\nyang tak pernah selesai.\r\n\r\nWalaupun laut digambarkan sebagai headline utama, buku ini sebenarnya tidak sepenuhnya membicarakan soal laut, tapi juga membahas tentang kesepian, kesunyian, kekecewaan, rindu, dan cinta yang dibalut dengan harapan untuk bisa hidup bersama orang tercinta.\r\n'),
('40040', '', 'Sepotong Hati di Angkringan', 4, 21, 56000, 'Pada suatu malam yang nyamnyam, kau menemukan sepotong hati yang lezat dalam sebungkus nasi kucing. Kau mengira itu hati ibumu atau hati kekasihmu. Namun, bisa saja itu hati orang yang pernah kausakiti atau menyakitimu. Angkringan adalah nama sebuah sunyi, tempat kau melerai hati, lebih-lebih saat hatimu disakiti sepi.'),
('40050', '', 'Museum Kehilangan', 4, 22, 32000, 'hari-hari mencuri wajahmu \r\nesok kita hanya mendengar suara tawa seorang nakhoda pemabuk\r\ndari neraka paling celaka dia bawa beribu cerita\r\nperihal menemukan seluruh harta karun yang kita cari\r\ntapi tak seorang pun akan percaya lagi\r\nsetelah di museum kehilangan: terpajang cermin,\r\nterpasung wajahmu\r\ndan kesunyian berabad-abad lamanya.\r\n\r\nBuku Museum Kehilangan merupakan karya buku kumpulan puisi ketiga dari Wawan Kurniawan yang mana berisikan 65 puisi dengan tema kehilangan.'),
('50010', '', 'Wow! Ensiklopedia 4D: Rahasia Samudra', 5, 23, 65000, '\r\nEnsiklopedia merupakan buku yang berisi mengenai keterangan tentang semua cabang pengetahuan, ilmu, dan teknologi, atau yang merangkum secara luas dan menyeluruh. Buku yang berjudul Wow! Ensiklopedia 4D: Rahasia Samudra dibuat dengan isi yang penuh gambar dan warna di setiap halamannya sehingga dapat menarik minat anak dalam membacanya. Selain itu banyak sekali manfaat bagi anak dalam membaca ensiklopedia, dimana diantaranya dapat menambah wawasan dalam pengetahuan, mengetahui suatu hal secara terperinci dan sesuai dengan fakta yang ada, dapat meningkatkan daya konsentrasi, mengasah memori pada anak, dan buku ensiklopedia juga menambah wawasan menjadi lebih luas dengan informasi-informasi yang terdapat di dalam buku tersebut.\r\n'),
('50020', '', 'Wow! Ensiklopedia 4D: Dunia Hewan', 5, 23, 65000, 'Ensiklopedia merupakan buku yang berisi mengenai keterangan tentang semua cabang pengetahuan, ilmu, dan teknologi, atau yang merangkum secara luas dan menyeluruh. Buku yang berjudul Wow! Ensiklopedia 4D: Dunia Hewan dibuat dengan isi yang penuh gambar dan warna di setiap halamannya sehingga dapat menarik minat anak dalam membacanya. Selain itu banyak sekali manfaat bagi anak dalam membaca ensiklopedia, dimana diantaranya dapat menambah wawasan dalam pengetahuan, mengetahui suatu hal secara terperinci dan sesuai dengan fakta yang ada, dapat meningkatkan daya konsentrasi, mengasah memori pada anak, dan buku ensiklopedia juga menambah wawasan menjadi lebih luas dengan informasi-informasi yang terdapat di dalam buku tersebut.\r\n'),
('99998', '', 'fsadfasf', 0, 0, 50000, 'sdfsdfsf'),
('99999', '', 'fsadfasf', 1, 0, 0, 'asdfsfsa');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'Novel'),
(2, 'Komik'),
(3, 'Biografi'),
(4, 'Antologi'),
(5, 'Ensiklopedi');

-- --------------------------------------------------------

--
-- Table structure for table `penulis`
--

CREATE TABLE `penulis` (
  `id_penulis` int(11) NOT NULL,
  `nama_penulis` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penulis`
--

INSERT INTO `penulis` (`id_penulis`, `nama_penulis`) VALUES
(1, 'Stephenie Meyer'),
(2, 'Suzanne Collins'),
(3, 'Leo Tolstoy'),
(4, 'Harper Lee'),
(5, 'F. Scott Fitzgerald'),
(6, 'Gabriel Garcia Marquez'),
(7, 'Miguel de Cervantes'),
(8, 'Akira Toriyama'),
(9, 'Rumiko Takahashi'),
(10, 'Masashi Kishimoto'),
(11, 'Hiromu Arakawa'),
(12, 'Hajime Isayama'),
(13, 'Haruichi Furudate'),
(14, 'Fajar Riza Ul Haq\r\n'),
(15, 'Iip D. Yahya'),
(16, 'Wartawan Harian Kompas dan Peneliti Litbang Kompas'),
(17, 'J. Anto'),
(18, 'Astri Apriyani'),
(19, 'Adimas Immanuel'),
(20, 'Ama Achmad'),
(21, 'Joko Pinurbo'),
(22, 'Wawan Kurniawan'),
(23, 'Devar Entertainment'),
(24, 'Polly Cheeseman'),
(25, 'Valerie Guidoux');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `username` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `email`, `password`, `nama`, `username`) VALUES
(12345, 'merah@gmail.com', '3b87069fd2ebbfc56207d3a31f550936', 'Asep Merah', 'asepmerah'),
(23451, 'kuning@gmail.com', '1ff02dbda3cfdda5b776b55ba73313a5', 'Budi Kuning', 'budikuning'),
(34512, 'hijau@gmail.com', 'hijau12345', 'Siska Hijau', 'siskahijau'),
(45123, 'biru@gmail.com', 'biru12345', 'Yanto Biru', 'yantobiru'),
(51234, 'ungu@gmail.com', 'ungu51234', 'Wawan Ungu', 'wawanungu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`isbn`),
  ADD KEY `id_kategori` (`id_kategori`),
  ADD KEY `id_penulis` (`id_penulis`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `penulis`
--
ALTER TABLE `penulis`
  ADD PRIMARY KEY (`id_penulis`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `penulis`
--
ALTER TABLE `penulis`
  MODIFY `id_penulis` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51235;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
