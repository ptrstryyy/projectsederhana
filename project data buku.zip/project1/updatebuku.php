<?php
    include 'koneksi.php';

    $isbn = $_POST['isbn'];
    $judul = $_POST['judul'];
    $kategori = $_POST['id_kategori'];
    $penulis = $_POST['id_penulis'];
    $deskripsi = $_POST['deskripsi'];
    $harga = $_POST['harga'];

    $cover=$_FILES["cover"]["name"];
    if ($cover) {
        $target_dir="img/cover/";
        $target_file=$target_dir.basename($cover);
        $namasementara=$_FILES["cover"]['tmp_name'];
        $terupload=move_uploaded_file($namasementara, $target_file);

        $query = "UPDATE buku SET isbn='$isbn', judul='$judul', cover='$cover', id_kategori='$kategori',id_penulis='$penulis', harga='$harga', deskripsi='$deskripsi' WHERE isbn='$isbn'";
    } else {
        $query = "UPDATE buku SET isbn='$isbn', judul='$judul', id_kategori='$kategori',id_penulis='$penulis', harga='$harga', deskripsi='$deskripsi' WHERE isbn='$isbn'";
    }

    $sql = mysqli_query($koneksi, $query);
    header("location: buku.php");

?>
