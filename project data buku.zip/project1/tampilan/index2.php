<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="/docs/5.3/assets/js/color-modes.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.122.0">
    <title>Signin Template · Bootstrap v5.3</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/sign-in/">

    

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Favicons -->
<link rel="apple-touch-icon" href="/docs/5.3/assets/img/favicons/apple-touch-icon.png" sizes="180x180">
<link rel="icon" href="/docs/5.3/assets/img/favicons/favicon-32x32.png" sizes="32x32" type="image/png">
<link rel="icon" href="/docs/5.3/assets/img/favicons/favicon-16x16.png" sizes="16x16" type="image/png">
<link rel="manifest" href="/docs/5.3/assets/img/favicons/manifest.json">
<link rel="mask-icon" href="/docs/5.3/assets/img/favicons/safari-pinned-tab.svg" color="#712cf9">
<link rel="icon" href="/docs/5.3/assets/img/favicons/favicon.ico">
<meta name="theme-color" content="#712cf9">


    <style>
      @media (max-width: 991px) {
  .navbar-scroll {
    background-color: #fff;
  }
     
  .navbar-scroll .navbar-brand,
  .navbar-scroll .nav-link,
  .navbar-scroll .fa-bars {
    color: #4f4f4f !important;
  }         
}

.navbar-brand {
  letter-spacing: 3px;
  font-size: 2rem;
  font-weight: 500;
}
.navbar-scroll .navbar-brand,
.navbar-scroll .nav-link,
.navbar-scroll .fa-bars {
  color: #fff;
}

.navbar-scroll {
  box-shadow: none;
}

.navbar-scrolled {
  box-shadow: 0 10px 20px 0 rgba(0, 0, 0, 0.05);
}

.navbar-scrolled .navbar-brand,
.navbar-scrolled .nav-link,
.navbar-scrolled .fa-bars {
  color: #4f4f4f;
}

.navbar-scrolled {
  background-color: #fff;
}

@media (max-width: 450px) {
  #intro {
    height: 950px !important;
  }
}

@media (min-width: 550px) and (max-width: 750px) {
  #intro {
    height: 1100px !important;
  }
}

@media (min-width: 800px) and (max-width: 990px) {
  #intro {
    height: 600px !important;
  }
}

.display-1 {
  font-weight: 500 !important;
  letter-spacing: 40px;
}

@media (min-width: 1600px) {
  .display-1 {
    font-size: 10rem;
  }
}
    </style>

    
    <!-- Custom styles for this template -->
    <link href=" https://getbootstrap.com/docs/5.3/examples/navbar-fixed/navbar-fixed.css " rel="stylesheet">
  </head>
  <body>
  <header>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg fixed-top navbar-scroll">
    <div class="container-fluid">
      <a class="navbar-brand" href="#!">CraftY</a>
      <button class="navbar-toggler" type="button" data-mdb-toggle="collapse"
        data-mdb-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
        aria-label="Toggle navigation">
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#!">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#!">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#!">Services</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#!">Attractions</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#!">Opinions</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#!">Contact</a>
          </li>
        </ul>
        <ul class="navbar-nav d-flex flex-row">
          <li class="nav-item me-3 me-lg-0">
            <a class="nav-link" href="#!">
              <i class="fas fa-shopping-cart"></i>
            </a>
          </li>
          <li class="nav-item me-3 me-lg-0">
            <a class="nav-link" href="#!">
              <i class="fab fa-twitter"></i>
            </a>
          </li>
          <li class="nav-item me-3 me-lg-0">
            <a class="nav-link" href="#!">
              <i class="fab fa-instagram"></i>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- Navbar -->

  <!--Section: Design Block-->
  <section>
    <div id="intro" class="bg-image" style="
        background-image: url('https://mdbootstrap.com/img/Photos/new-templates/craftsman/img(1).jpg');
        height: 100vh;
      ">
      <div class="mask" style="background-color: rgba(0, 0, 0, 0.2);">
        <div class="container d-flex justify-content-center align-items-center h-100">
          <div class="row align-items-center">
            <div class="col-12">
              <h1 class="mb-0 text-white display-1">Studio</h1>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--Section: Design Block-->
</header>

 <main>
   <div class="container my-5 py-5"></div>
</main>
</body>
</html>











<?php 
include 'koneksi.php';
include("header.php"); ?>

<div class="album py-5"><br><br> <!--bg-body-tertiary-->
        <h2 align="center"><strong>Tambah Data Buku</strong></h2><br>
            <div class="container">
                <div align="left" class="">
                        
                    <table class="table table-bordered">
                        
                        <form action="simpanbuku.php" method="POST">
                            <div class="mb-3 row">
                                <label for="inputtext" class="col-sm-2 col-form-label">Nomor ISBN</label>
                                <div class="col-sm-10">
                                  <input type="text" class="form-control" id="inputtext" name="isbn" placeholder="masukan nomor ISBN">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Judul Buku</label>
                                <div class="col-sm-10">
                                  <input type="password" class="form-control" id="inputPassword" name="judul" placeholder="masukan judul buku">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Penulis </label>
                                <div class="col-sm-10">
                                  <input type="password" class="form-control" id="inputPassword" name="penulis" placeholder="masukan penulis" required>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label for="kategori" class="col-sm-2 col-form-label">Kategori </label>
                                <div class="col-sm-10">
                                    <select name="id_kategori" class="form-control">
                                        <?php
                                        $kategori= mysqli_fetch_array($koneksi,"SELECT * FROM kategori");
                                        while($k=mysqli_fetch_array($kategori)){
                                            echo "<option value=' ".$k['id_kategori']."'>".$k['nama_kategori']."</option> ";
                                        }
                                        ?>
                                   </select>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label for="inputtext" class="col-sm-2 col-form-label">Deskripsi </label>
                                <div class="col-sm-10">
                                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="deskripsi" placeholder="masukan deskripsi"></textarea>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label for="inputtext" class="col-sm-2 col-form-label">Harga </label>
                                <div class="col-sm-10">
                                  <input type="text" class="form-control" id="" name="harga" placeholder="masukan harga">
                                </div>
                            </div>
                            <br> 
                            
                          
                            <!-- Submit button -->
                            <div>
                                <button type="button" class="btn btn-success me-md-2">Tambah</button>
                                <button type="button" class="btn btn-danger"><a href="buku.php" style="color: white;"> Batal </a></button>
                            </div>
                            </form>
                    </table>
                </div>

                
            </div>
        </div>

</body>


<!--include 'footer.php';

                    while($buku = mysqli_fetch_array($query)){
                    echo "<tr>";

                        echo "<td>".$buku['isbn']."</td>";
                        echo "<td>".$buku['judul']."</td>";
                        echo "<td>".$buku['id_kategori']."</td>";
                        echo "<td>".$buku['id_penulis']."</td>";
                        echo "<td>".$buku['deskripsi']."</td>";
                        echo "<td>".$buku['harga']."</td>";

                        echo "<td>";
                        echo "<button><a href='form-edit.php?id=".$buku['isbn']."'>Edit</a></button> ";
                        echo "<button><a href='hapus.php?id=".$buku['isbn']."'>Hapus</a></button>";
                        echo "</td>";

                    echo "</tr>";
                    
                        
-->