<?php 
include("header.php");
include 'koneksi.php'; 
$id = $_GET['id_kategori'];
$sql = mysqli_query($koneksi,"SELECT * FROM kategori WHERE id_kategori='$id'");
$kategori = mysqli_fetch_array($sql);
?>


<div class="album py-5 fade-in-up"><br><br> <!--bg-body-tertiary-->
        <h2 align="center" class="text-white"><strong>Edit Kategori Buku</strong></b></h2><br>
            <div class="container shadow-sm p-3 mb-5 bg-body-tertiary rounded p-2 text-dark bg-opacity-50">
                <div align="left" class="">
                        
                    <table class="table table-bordered">
                        
                    <form action="updatekategori.php" method="POST">
                            <div class="mb-3 row">
                                <label for="idkategori" class="col-sm-2 col-form-label">Nama Kategori </label>
                                <div class="col-sm-10">
                                  <input value="<?php echo $kategori['id_kategori']?>" type="text" class="form-control" id="kategori" name="id_kategori">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="namakategori" class="col-sm-2 col-form-label">Nama Kategori </label>
                                <div class="col-sm-10">
                                  <input value="<?php echo $kategori['nama_kategori']?>" type="text" class="form-control" id="kategori" name="nama_kategori">
                                </div>
                            </div>
                            <br>

                            
                          
                            <!-- Submit button -->
                            <div>
                                <button type="submit" class="btn btn-success me-md-2">Simpan</button>
                                <button type="button" class="btn btn-danger"><a href="kategori.php" class="white-link"> Batal </a></button>
                            </div>
                            </form>
                    </table>
                </div>

                
            </div>
        </div>

</body>


<!--include 'footer.php';

                    while($buku = mysqli_fetch_array($query)){
                    echo "<tr>";

                        echo "<td>".$buku['isbn']."</td>";
                        echo "<td>".$buku['judul']."</td>";
                        echo "<td>".$buku['id_kategori']."</td>";
                        echo "<td>".$buku['id_penulis']."</td>";
                        echo "<td>".$buku['deskripsi']."</td>";
                        echo "<td>".$buku['harga']."</td>";

                        echo "<td>";
                        echo "<button><a href='form-edit.php?id=".$buku['isbn']."'>Edit</a></button> ";
                        echo "<button><a href='hapus.php?id=".$buku['isbn']."'>Hapus</a></button>";
                        echo "</td>";

                    echo "</tr>";
                    
                        
-->