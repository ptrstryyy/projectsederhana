<?php
include 'koneksi.php';
session_start();
//cek input form
$username = $_POST['username'];
$password = md5($_POST['password']);

//melakukan pengecekan ke tabel user
$sql="select * from user where (username='$username' or email='$username') and password='$password'";
//melakukan konversi hasil menajadi array
$user = mysqli_fetch_array(mysqli_query($koneksi, $sql));

//cek apakah memiliki hasil dari query di atas
if($user){
    //echo "Login berhasil!");
    $_SESSION['nama'] = $user['nama'];
    header("location:buku.php");
}
else{
   // echo "Login gagal! Email atau password salah.";
    header("location:index.php");
}


?>


<!--
//cek input form
$email = $_POST['email'];
$password = $_POST['password'];

echo $email;
echo "<br>";
echo $password;
echo "<br>";

//cek apakah login sudah benar
if($email =='email@gmail.com' && $password =='password'){
    echo "Login berhasil!";
}
else{
    echo "Login gagal! Email atau password salah.";
}
-->

<!--exit();-->